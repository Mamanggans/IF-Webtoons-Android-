package app.uangkas;

import android.view.View;

public interface IRecyclerViewClickListener
{
    void onClick(View view, int position);
}